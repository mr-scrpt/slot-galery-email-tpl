<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

$recipients = [
    'dolcegabbana2010@gmail.com',
];

$smtp_config = [
    'host' => 'smtp.gmail.com',
    'username' => 'paulmacron33@gmail.com',
    'password' => 'ncbs vbvn dtmh xkgc',
    'port' => 587,
    'encryption' => 'tls',
];

function sendEmail($to, $subject) {
    global $smtp_config;

    // Загружаем HTML шаблон
    $htmlTemplate = file_get_contents('./simple.html');
    if (!$htmlTemplate) {
        throw new Exception('Не удалось загрузить HTML шаблон');
    }

    $mail = new PHPMailer(true);

    try {
        // Настройка SMTP
        $mail->isSMTP();
        $mail->Hostname = 'aceit.group';
        $mail->Host = $smtp_config['host'];
        $mail->SMTPAuth = true;
        $mail->Username = $smtp_config['username'];
        $mail->Password = $smtp_config['password'];
        $mail->SMTPSecure = $smtp_config['encryption'];
        $mail->Port = $smtp_config['port'];
        $mail->CharSet = 'UTF-8';
        
        $mail->setFrom($smtp_config['username'], 'AceIT Website Form');
        
        $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail->Debugoutput = function($str, $level) {
            writeLog('SMTP_DEBUG', $str);
        };

        // Получатель
        $mail->addAddress($to);

        // Настройка HTML-контента
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $htmlTemplate;
        $mail->AltBody = 'Новая заявка с сайта AceIT. Для просмотра требуется HTML.';

        $mail->send();
        return true;
    } catch (Exception $e) {
        writeLog('ERROR', "Ошибка отправки письма: {$mail->ErrorInfo}");
        return false;
    }
}

function writeLog($type, $message, $data = null) {
    $logDir = __DIR__ . '/logs';
    if (!file_exists($logDir)) {
        mkdir($logDir, 0755, true);
    }
    $date = date('Y-m-d H:i:s');
    $logMessage = "[$date] [$type] $message\n";
    if ($data) {
        $logMessage .= "Data: " . print_r($data, true) . "\n";
    }
    $logMessage .= "------------------------------------------------\n";
    $filename = $type === 'ERROR' ? 'error.log' : 'success.log';
    file_put_contents($logDir . '/' . $filename, $logMessage, FILE_APPEND);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        writeLog('INFO', 'Начало отправки писем');

        $subject = 'Новая заявка с сайта';
        $allSuccess = true;
        $sentTo = [];

        foreach ($recipients as $to) {
            try {
                if (sendEmail($to, $subject)) {
                    $sentTo[] = $to;
                    writeLog('SUCCESS', "Письмо успешно отправлено на $to");
                } else {
                    $allSuccess = false;
                    writeLog('ERROR', "Не удалось отправить письмо на $to");
                }
            } catch (Exception $e) {
                $allSuccess = false;
                writeLog('ERROR', "Исключение при отправке на $to: " . $e->getMessage());
            }
        }

        if ($allSuccess) {
            writeLog('SUCCESS', 'Письма успешно отправлены', [
                'to' => $sentTo,
                'subject' => $subject
            ]);
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'Сообщения успешно отправлены'
            ]);
        } else {
            throw new Exception('Ошибка при отправке некоторых писем');
        }

    } catch (Exception $e) {
        writeLog('ERROR', $e->getMessage(), [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Ошибка: ' . $e->getMessage()
        ]);
    }
} else {
    writeLog('ERROR', 'Неразрешенный метод: ' . $_SERVER['REQUEST_METHOD']);
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Метод не разрешен'
    ]);
}
?>
