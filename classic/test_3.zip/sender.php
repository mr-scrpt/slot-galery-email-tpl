<?php
// Подключаем autoload PHPMailer (если установлен через composer)
require 'vendor/autoload.php'; // или укажите путь к файлу autoload.php

// Создаём экземпляр PHPMailer
$mail = new PHPMailer\PHPMailer\PHPMailer();

$smtp_config = [
    'host' => 'smtp.gmail.com',
    'username' => 'paulmacron33@gmail.com',
    'password' => 'ncbs vbvn dtmh xkgc ',
    'port' => 587,
    #'encryption' => PHPMailer::ENCRYPTION_STARTTLS
    'encryption' => 'tls',
];


// Настраиваем SMTP
$mail->isSMTP();
$mail->Host       = $smtp_config['host'];
$mail->SMTPAuth   = true;
$mail->Username   = $smtp_config['username'];
$mail->Password   = $smtp_config['password'];
$mail->SMTPSecure = $smtp_config['encryption'];
$mail->Port       = 587;                      // Порт SMTP-сервера

// Устанавливаем кодировку
$mail->CharSet = 'UTF-8';

// Настраиваем отправителя и получателя
$mail->setFrom($smtp_config['username'], 'Name');
$mail->addAddress('dolcegabbana2010@gmail.com', 'Your Name');

$mail->isHTML(true);

// Задаём тему письма
$mail->Subject = 'Тема письма';

// Подготавливаем HTML шаблон (можно загружать из файла)
$htmlTemplate = file_get_contents('./tpl.html');

// Если в шаблоне есть маркеры, заменяем их нужными значениями
$htmlTemplate = str_replace('{{username}}', 'Имя пользователя', $htmlTemplate);

// Задаём тело письма
$mail->Body = $htmlTemplate;

// Альтернативное тело (для клиентов, не поддерживающих HTML)
$mail->AltBody = 'Текстовая версия письма';

// Отправляем письмо и обрабатываем ошибки
if(!$mail->send()){
    echo 'Ошибка при отправке письма: ' . $mail->ErrorInfo;
} else {
    echo 'Письмо успешно отправлено';
}
?>

